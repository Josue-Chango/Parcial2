﻿using shappes_2d;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OperacionDDA
{
    internal class OperacionDDA
    {

        public OperacionDDA() { }
        int x1, y1, x2, y2, pasos;
        public System.Collections.Generic.List<string> puntosLista = new System.Collections.Generic.List<string>();

        public void ClearPuntosLista()
        {
            puntosLista.Clear();
        }


        public int calcularX(int x1, int x2)
        {
            return x2 - x1;
        }
        public int calcularY(int y1, int y2)
        {
            return y2 - y1;
        }

        public void DDA(Graphics g, int x1, int y1, int x2, int y2, Color color)
        {
            ClearPuntosLista();
            int dx = calcularX(x1, x2);
            int dy = calcularY(y1, y2);
            int pasos = Math.Max(Math.Abs(dx), Math.Abs(dy));
            using (Brush brush = new SolidBrush(color))
            {
                if (pasos == 0)
                {
                    puntosLista.Add($"({x1}, {y1})");
                    g.FillRectangle(brush, x1, y1, 1, 1);
                    return;
                }

                float xIncrement = (float)dx / pasos;
                float yIncrement = (float)dy / pasos;
                float x = x1;
                float y = y1;
                for (int i = 0; i <= pasos; i++)
                {
                    int xr = (int)Math.Round(x);
                    int yr = (int)Math.Round(y);
                    puntosLista.Add($"({xr}, {yr})");
                    g.FillRectangle(brush, xr, yr, 1, 1);
                    x += xIncrement;
                    y += yIncrement;
                }
            }
        }

        public void DibujarPlano(Graphics g, int Ancho, int Alto, int CentroX, int CentroY)
        {
            int paso = 10;

            using (Pen cuadricula = new Pen(Color.LightGray, 1))
            {
                for (int x = CentroX; x < Ancho; x += paso)
                {
                    g.DrawLine(cuadricula, x, 0, x, Alto);
                }
                for (int x = CentroX - paso; x >= 0; x -= paso)
                {
                    g.DrawLine(cuadricula, x, 0, x, Alto);
                }

                for (int y = CentroY; y < Alto; y += paso)
                {
                    g.DrawLine(cuadricula, 0, y, Ancho, y);
                }
                for (int y = CentroY - paso; y >= 0; y -= paso)
                {
                    g.DrawLine(cuadricula, 0, y, Ancho, y);
                }
            }

            using (Pen ejeX = new Pen(Color.Red, 2))
            using (Pen ejeY = new Pen(Color.Blue, 2))
            {
                g.DrawLine(ejeX, 0, CentroY, Ancho, CentroY);
                g.DrawLine(ejeY, CentroX, 0, CentroX, Alto);
            }
        }


        public void DDACentrado(Graphics g, int x1, int y1, int x2, int y2, Color color, int CentroX, int CentroY)
        {
            ClearPuntosLista();
            int dx = calcularX(x1, x2);
            int dy = calcularY(y1, y2);
            pasos = Math.Max(Math.Abs(dx), Math.Abs(dy));
            using (Brush brush = new SolidBrush(color))
            {
                if (pasos == 0)
                {
                    puntosLista.Add($"({x1}, {y1})");
                    g.FillRectangle(brush, x1 + CentroX, CentroY - y1, 1, 1);
                    return;
                }

                float xIncrement = (float)dx / pasos;
                float yIncrement = (float)dy / pasos;
                float x = x1;
                float y = y1;
                for (int i = 0; i <= pasos; i++)
                {
                    int xr = (int)Math.Round(x);
                    int yr = (int)Math.Round(y);
                    puntosLista.Add($"({xr}, {yr})");
                    g.FillRectangle(brush, xr + CentroX, CentroY - yr, 1, 1);
                    x += xIncrement;
                    y += yIncrement;
                }
            }
        }

        public void Bresenham(Graphics g, int x1, int y1, int x2, int y2, Color color, int CentroX, int CentroY)
        {
            ClearPuntosLista();
            int dx = Math.Abs(calcularX(x1, x2));
            int dy = Math.Abs(calcularY(y1, y2));
            int sx = x1 < x2 ? 1 : -1;
            int sy = y1 < y2 ? 1 : -1;
            int err = dx - dy;

            using (Brush brush = new SolidBrush(color))
            {
                pasos = 0;
                while (true)
                {
                    puntosLista.Add($"({x1}, {y1})");
                    g.FillRectangle(brush, x1 + CentroX, CentroY - y1, 1, 1);
                    pasos++;

                    if (x1 == x2 && y1 == y2) break;

                    int e2 = 2 * err;
                    if (e2 > -dy)
                    {
                        err -= dy;
                        x1 += sx;
                    }
                    if (e2 < dx)
                    {
                        err += dx;
                        y1 += sy;
                    }
                }
            }
        }

        public void PuntoMedio(Graphics g, int x1, int y1, int x2, int y2, Color color, int CentroX, int CentroY)
        {
            ClearPuntosLista();
            int dx = calcularX(x1, x2);
            int dy = calcularY(y1, y2);
            
            int incX = dx > 0 ? 1 : -1;
            int incY = dy > 0 ? 1 : -1;
            
            dx = Math.Abs(dx);
            dy = Math.Abs(dy);

            using (Brush brush = new SolidBrush(color))
            {
                pasos = 0;
                int x = x1;
                int y = y1;

                puntosLista.Add($"({x}, {y})");
                g.FillRectangle(brush, x + CentroX, CentroY - y, 1, 1);
                pasos++;

                if (dx > dy)
                {
                    int p = 2 * dy - dx;
                    int incE = 2 * dy;
                    int incNE = 2 * (dy - dx);

                    for (int i = 0; i < dx; i++)
                    {
                        if (p < 0)
                        {
                            p += incE;
                            x += incX;
                        }
                        else
                        {
                            p += incNE;
                            x += incX;
                            y += incY;
                        }
                        puntosLista.Add($"({x}, {y})");
                        g.FillRectangle(brush, x + CentroX, CentroY - y, 1, 1);
                        pasos++;
                    }
                }
                else
                {
                    int p = 2 * dx - dy;
                    int incN = 2 * dx;
                    int incNE = 2 * (dx - dy);

                    for (int i = 0; i < dy; i++)
                    {
                        if (p < 0)
                        {
                            p += incN;
                            y += incY;
                        }
                        else
                        {
                            p += incNE;
                            x += incX;
                            y += incY;
                        }
                        puntosLista.Add($"({x}, {y})");
                        g.FillRectangle(brush, x + CentroX, CentroY - y, 1, 1);
                        pasos++;
                    }
                }
            }
        }

        public int getPasos()
        {
            return pasos;
        }


        public void DibujarAnimado(Graphics g, Color color, int cantidad, int CentroX, int CentroY)
            {
                using (Brush brush = new SolidBrush(color))
                {
                    for (int i = 0; i < cantidad && i < puntosLista.Count; i++)
                    {
                        string[] coords = puntosLista[i]
                            .Trim('(', ')')
                            .Split(',');

                        int x = int.Parse(coords[0]);
                        int y = int.Parse(coords[1]);

                        g.FillRectangle(
                            brush,
                            x + CentroX,
                            CentroY - y,
                            1,
                            1);
                    }
                }
            }

        public void GenerarDDA(int x1, int y1, int x2, int y2)
        {
            ClearPuntosLista();

            int dx = calcularX(x1, x2);
            int dy = calcularY(y1, y2);

            pasos = Math.Max(Math.Abs(dx), Math.Abs(dy));

            if (pasos == 0)
            {
                puntosLista.Add($"({x1}, {y1})");
                return;
            }

            float xIncrement = (float)dx / pasos;
            float yIncrement = (float)dy / pasos;

            float x = x1;
            float y = y1;

            for (int i = 0; i <= pasos; i++)
            {
                puntosLista.Add($"({Math.Round(x)}, {Math.Round(y)})");

                x += xIncrement;
                y += yIncrement;
            }
        }

        public void GenerarBresenham(int x1, int y1, int x2, int y2)
        {
            ClearPuntosLista();

            int dx = Math.Abs(calcularX(x1, x2));
            int dy = Math.Abs(calcularY(y1, y2));

            int sx = x1 < x2 ? 1 : -1;
            int sy = y1 < y2 ? 1 : -1;

            int err = dx - dy;

            pasos = 0;

            while (true)
            {
                puntosLista.Add($"({x1}, {y1})");
                pasos++;

                if (x1 == x2 && y1 == y2)
                    break;

                int e2 = 2 * err;

                if (e2 > -dy)
                {
                    err -= dy;
                    x1 += sx;
                }

                if (e2 < dx)
                {
                    err += dx;
                    y1 += sy;
                }
            }
        }

        public void GenerarPuntoMedio(int x1, int y1, int x2, int y2)
        {
            ClearPuntosLista();

            int dx = calcularX(x1, x2);
            int dy = calcularY(y1, y2);

            int incX = dx > 0 ? 1 : -1;
            int incY = dy > 0 ? 1 : -1;

            dx = Math.Abs(dx);
            dy = Math.Abs(dy);

            pasos = 0;

            int x = x1;
            int y = y1;

            puntosLista.Add($"({x}, {y})");
            pasos++;

            if (dx > dy)
            {
                int p = 2 * dy - dx;
                int incE = 2 * dy;
                int incNE = 2 * (dy - dx);

                for (int i = 0; i < dx; i++)
                {
                    if (p < 0)
                    {
                        p += incE;
                        x += incX;
                    }
                    else
                    {
                        p += incNE;
                        x += incX;
                        y += incY;
                    }

                    puntosLista.Add($"({x}, {y})");
                    pasos++;
                }
            }
            else
            {
                int p = 2 * dx - dy;
                int incN = 2 * dx;
                int incNE = 2 * (dx - dy);

                for (int i = 0; i < dy; i++)
                {
                    if (p < 0)
                    {
                        p += incN;
                        y += incY;
                    }
                    else
                    {
                        p += incNE;
                        x += incX;
                        y += incY;
                    }

                    puntosLista.Add($"({x}, {y})");
                    pasos++;
                }
            }
        }

    }
}
